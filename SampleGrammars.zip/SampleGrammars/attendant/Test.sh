../../bin/linux/julius -C testmic.jconf
